﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PS2_TEST.Utilities
{
    public static class Utility
    {
        public enum PackingType
        {
            Shipping = 1,
            Royalty = 2
        }
    }
}
